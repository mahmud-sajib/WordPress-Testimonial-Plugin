(function ($) {
    "use strict";

    jQuery(document).ready(function ($) {

        //--------------------testimonial page carousel---------------------
        $(".t_carousel").owlCarousel({
            items: 1,
            loop: true,
            dots: false,
            nav: true,
            navText: ["<i class='flaticon-arrows-2'></i>", "<i class='flaticon-arrows-1'></i>"],
            autoplay: true,
            smartSpeed: 1200
        });


        /*--------Testimonial Slick Carousel as Nav---------------*/
        $('.slider-nav').slick({
            slidesToShow: 3,
            slidesToScroll: 1,
            asNavFor: '.slider-for',
            dots: false,
            arrows: true,
            autoplay: true,
            autoplaySpeed: 3000,
            prevArrow: '<i class="fa fa-long-arrow-left"></i>',
            nextArrow: '<i class="fa fa-long-arrow-right"></i>',
            centerMode: true,
            focusOnSelect: true,
            centerPadding: '10px',
            responsive: [
                {
                    breakpoint: 450,
                    settings: {
                        dots: false,
                        slidesToShow: 3,
                        centerPadding: '0px',
                    }
            },
                {
                    breakpoint: 420,
                    settings: {
                        autoplay: true,
                        dots: false,
                        slidesToShow: 1,
                        centerMode: false,
                    }
            }
        ]
        });

    });

}(jQuery));
