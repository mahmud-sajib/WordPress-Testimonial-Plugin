<?php
//uninstalling the plugin
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}