<?php
//creating metaboxes
function lt_create_metaboxes(){
	add_meta_box(
		'lt_testimonial_options',
		__('Testimonial Options', 'live-testimonial'),
		'lt_testimonial_options',
		'testimonial',
		'normal',
		'high'
	);
}
// metabox callback function
function lt_testimonial_options($post){

	$lt_testimonial_data = get_post_meta( $post->ID, 'lt_testimonial_data', true );
//setting the metabox value as empty when there is no metadata exists
	if (empty($lt_testimonial_data)) {
		$lt_testimonial_data                  =   array();
		$lt_testimonial_data['lt_name']       =   '';
		$lt_testimonial_data['lt_quote']      =   '';
	}

	?>

	<p>
		<label for="lt_name"><?php _e( 'Customer\'s Name', 'live-testimonial' ); ?></label>
	    <input type="text" class="widefat" id="lt_name" name="lt_inputName" 
	    value="<?php echo $lt_testimonial_data['lt_name']; ?>">
	</p>

	<p>
		<label for="lt_quote"><?php _e( 'Customer\'s Quote', 'live-testimonial' ); ?></label>
	    <textarea name="lt_inputQuote" id="lt_quote" class="widefat" cols="60" rows="8"><?php echo $lt_testimonial_data['lt_quote']; ?></textarea>
	</p>

	<p><strong>Please use the Featured Image option to upload a logo or photo</strong></p>

	<?php
}
