<?php

// saving the post information retrieved from metabox
function lt_save_post_admin($post_id, $post, $update){
	if( !$update ){
		return;
	}
	
	$lt_testimonial_data                  =   array();
	$lt_testimonial_data['lt_name']       =   sanitize_text_field( $_POST['lt_inputName'] );
	$lt_testimonial_data['lt_quote']      =   sanitize_text_field( $_POST['lt_inputQuote'] );

	//updating post information
	update_post_meta( $post_id, 'lt_testimonial_data', $lt_testimonial_data );
}