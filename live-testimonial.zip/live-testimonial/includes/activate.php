<?php
function lt_activate_plugin(){

	//comparing wordpress version during activation
	if( version_compare( get_bloginfo( 'version' ), '4.5', '<' ) ){
        wp_die( __( 'You must update WordPress to use this plugin', 'live-testimonial' ) );
    }

    // rewriting rules for custom post's permalink setting
    lt_post_init();
    flush_rewrite_rules();

}