<?php
//filtering contents for live testimonial post type
function lt_filter_testimonial_content($content){
	if (!is_singular('testimonial')) {
		return $content;
	}

	global $post;

	$lt_testimonial_data = get_post_meta($post->ID, 'lt_testimonial_data', true);
	$lt_testimonial_name = $lt_testimonial_data['lt_name'];
	$lt_testimonial_content = $lt_testimonial_data['lt_quote'];

	return $lt_testimonial_name ."<br/>"."<br/>". $lt_testimonial_content;

}