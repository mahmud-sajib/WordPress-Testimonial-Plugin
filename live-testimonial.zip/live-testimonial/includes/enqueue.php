<?php
// enqueuing styles and scripts
function lt_enqueue_scripts(){
	wp_register_style(
		'lt_fonts_css', 
		plugins_url('/assets/css/theme.fonts.css', LIVETESTIMONIAL_PLUGIN_URL)
	);

	wp_register_style(
		'lt_bootstrap_css', 
		plugins_url('/assets/css/bootstrap.min.css', LIVETESTIMONIAL_PLUGIN_URL)
	);

	wp_register_style(
		'lt_owl_css', 
		plugins_url('/assets/css/owl.carousel.min.css', LIVETESTIMONIAL_PLUGIN_URL)
	);

	wp_register_style(
		'lt_slick_css', 
		plugins_url('/assets/css/slick.css', LIVETESTIMONIAL_PLUGIN_URL)
	);

	wp_register_style(
		'lt_global_css', 
		plugins_url('/assets/css/global-style.css', LIVETESTIMONIAL_PLUGIN_URL)
	);

	wp_enqueue_style('lt_fonts_css');
	wp_enqueue_style('lt_bootstrap_css');
	wp_enqueue_style('lt_owl_css');
	wp_enqueue_style('lt_slick_css');
	wp_enqueue_style('lt_global_css');

	wp_register_script(
		'lt_bootstrap_js', 
		plugins_url('/assets/js/bootstrap.min.js', LIVETESTIMONIAL_PLUGIN_URL),
		array('jquery'),
		'',
		true
	);

	wp_register_script(
		'lt_owl_js', 
		plugins_url('/assets/js/owl.carousel.min.js', LIVETESTIMONIAL_PLUGIN_URL),
		array('jquery'),
		'',
		true
	);

	wp_register_script(
		'lt_slick_js', 
		plugins_url('/assets/js/slick.js', LIVETESTIMONIAL_PLUGIN_URL),
		array('jquery'),
		'',
		true
	);

	wp_register_script(
		'lt_main_js', 
		plugins_url('/assets/js/main.js', LIVETESTIMONIAL_PLUGIN_URL),
		array('jquery'),
		'',
		true
	);

	wp_enqueue_script('lt_bootstrap_js');
	wp_enqueue_script('lt_owl_js');
	wp_enqueue_script('lt_slick_js');
	wp_enqueue_script('lt_main_js');




}
