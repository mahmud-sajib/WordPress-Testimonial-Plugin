<?php
// callback function for admin init hook
function testimonial_admin_init(){
	include('column.php');
    //hooks for custom admin columns for live testimonial posts
	add_filter('manage_testimonial_posts_columns', 'hq_add_new_testimonial_column');
	add_action('manage_testimonial_posts_custom_column', 'hq_manage_testimonial_column',10,2);

}