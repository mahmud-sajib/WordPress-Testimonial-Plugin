<?php
// registering a custom post for testimonial
function lt_post_init(){

	register_post_type( 'testimonial', array(
		'labels' => array(
			'name'         => __('Testimonial','live-testimonial'),
			'add_new' => __( 'Add New Testimonial', 'live-testimonial' ),
			'add_new_item' => __( 'Add New Testimonial', 'live-testimonial' )
		),

	'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'testimonial' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_icon' => 'dashicons-format-quote',
        'menu_position'      => 20,
        'supports'           => array( 'title', 'author', 'thumbnail' ),
        
	));

}