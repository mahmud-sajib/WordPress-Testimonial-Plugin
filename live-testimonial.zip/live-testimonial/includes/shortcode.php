<?php
// live testimonial shortcode
function testimonial_slider_shortcode(){
global $post;
	
ob_start();?>
<section class="testimonial_style">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="testimonial_wrapper owl-carousel t_carousel">
					<?php
					// start looping through the posts
					$testimonialSlide = new WP_Query(array(
					'post_type' => 'testimonial',
					'posts_per_page' => -1
					));
					?>
					<?php
						if ($testimonialSlide->have_posts()) {
							while ($testimonialSlide->have_posts()) {
							$testimonialSlide->the_post();
							// fetching post information
					$lt_testimonial_data = get_post_meta($post->ID, 'lt_testimonial_data', true);
					?>
					<div class="single_testimonial align_row_center_left">
						<div class="author_img">
							<?php
							if (has_post_thumbnail()) {
							the_post_thumbnail(array(130,130),array('class' => 'radius_100p'));
							}
							?>
						</div>
						<div class="author_info">
							<h5>
							<?php echo $lt_testimonial_data['lt_name']; ?>
							</h5>
							<p class="author_comment">
								<?php echo $lt_testimonial_data['lt_quote']; ?>
							</p>
						</div>
					</div>
					<?php
						}
						wp_reset_postdata();
						}
					?>
				</div>
			</div>
		</div>
	</div>
</section>


<?php $testimonial_block = ob_get_clean();
return $testimonial_block;
}
//creating the shortcode for frontend publishing
add_shortcode('lt_testimonials','testimonial_slider_shortcode');
?>