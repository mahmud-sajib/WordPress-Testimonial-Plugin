<?php
//deactivating the plugin
function lt_deactivate_plugin(){
	echo "Please update the permalink structure if you find any issue";
}