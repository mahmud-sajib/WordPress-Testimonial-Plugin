<?php
// wordpress default columns for custom post admin screen 
function hq_add_new_testimonial_column($columns){

	$new_columns                    = array();

	$new_columns['cb']              = '<input type="checkbox" />';
    $new_columns['title']           = __('Title','live-testimonial');
    $new_columns['name']            = __('Name','live-testimonial');
    $new_columns['quote']           = __('Quote','live-testimonial');
    $new_columns['date']            = __('Date','live-testimonial');

    return $new_columns;

}

// creating custom columns for custom post admin screen 
function hq_manage_testimonial_column($column,$post_id){
	switch ($column) {
		case 'name':
			$lt_testimonial_data  =   get_post_meta( $post_id, 'lt_testimonial_data', true );
			echo $lt_testimonial_data['lt_name'];
			break;

		case 'quote':
			$lt_testimonial_data =   get_post_meta( $post_id, 'lt_testimonial_data', true );
			echo $lt_testimonial_data['lt_quote'];
			break;

		default:
			# code...
			break;
	}
}