<?php
/*
Plugin Name: Live Testimonial
Description: A simple testimonial plugin
Version: 1.0.0
Author: Mahmud Sajib
Author URI: https://mahmud-sajib.me/
License: GPLv2
Text Domain: live-testimonial
*/


// Make sure we don't expose any info if called directly
if ( !function_exists( 'add_action' ) ) {
	echo 'Hi there!  I\'m just a plugin, not much I can do when called directly.';
	exit;
}


//setup 
define( 'LIVETESTIMONIAL_PLUGIN_URL', __FILE__ );

//includes

include('includes/activate.php');
include('includes/testimonial_init.php');
include('includes/admin_init.php');
include('includes/metabox.php');
include('includes/save_post.php');
include('includes/enqueue.php');
include('includes/shortcode.php');
include('includes/filter_content.php');



//hooks

register_activation_hook( __FILE__, 'lt_activate_plugin' );
register_deactivation_hook( __FILE__, 'lt_deactivate_plugin' );
add_action( 'init', 'lt_post_init' );
add_action( 'admin_init', 'testimonial_admin_init' );
add_action( 'add_meta_boxes_testimonial','lt_create_metaboxes');
add_action( 'save_post_testimonial', 'lt_save_post_admin', 10, 3 );
add_action( 'wp_enqueue_scripts', 'lt_enqueue_scripts', 10 );
add_filter( 'the_content','lt_filter_testimonial_content' );
